////
////  AddressViewModel.swift
////  GiveawayInsel
////
////  Created by Muhammad Ameen Qadri on 01.04.24.
////
//
//import Foundation
//
//
//public class AddressList<T: GenericAddressProtocol>: ObservableObject {
//    @Published public var addresses: [T]
//    
//    @Published var isNewAddressSheetOpen: Bool = false
//    @Published var title: String = Constants.EMPTY_STRING
//    @Published var addressLine1: String = Constants.EMPTY_STRING
//    @Published var addressLine2: String = Constants.EMPTY_STRING
//    @Published var postalCode: String = Constants.EMPTY_STRING
//    @Published var city: String = Constants.EMPTY_STRING
//   
//    public init(addresses: [T] = []) {
//        self.addresses = addresses
//    }
//    
//    func addNewAddress() {
//        let newAddress = GenericAddressProtocol(id: UUID().uuidString,
//                                 title: self.title,
//                                 addressLine1: self.addressLine1,
//                                 addressLine2: self.addressLine2,
//                                 postalCode: self.postalCode,
//                                 city: self.city)
//        addresses.append(<#T##newElement: GenericAddressProtocol##GenericAddressProtocol#>)
//       
//    }
//    func getAddress() {
//       
//    }
//    func deleteAddress(addressId: String) {
//        addresses.removeAll { $0.id == addressId }
//    }
//   
//    func openNewAddressSheet() { isNewAddressSheetOpen.toggle() }
//}
