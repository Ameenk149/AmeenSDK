////
////  AddressModel.swift
////  GiveawayInsel
////
////  Created by Muhammad Ameen Qadri on 01.04.24.
////
//
//import Foundation
//
//struct Address: Identifiable, Codable {
//    var id: String
//    var title: String
//    var addressLine1: String
//    var addressLine2: String
//    var postalCode: String
//    var city: String
//    
//    public init(id: String, title: String, addressLine1: String, addressLine2: String, postalCode: String, city: String) {
//        self.id = id
//        self.title = title
//        self.addressLine1 = addressLine1
//        self.addressLine2 = addressLine2
//        self.postalCode = postalCode
//        self.city = city
//    }
//}
